#include <iostream.h>
#include <conio.h>

int main()
{
	clrscr();
	cout<<"I work.";
	getch();
	return 0;
}
