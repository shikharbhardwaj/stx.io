/**
Interface Programming Question 1.

Simply, find the rank of the word as it appears in the dictionary.
For eg,
	in the word MOON,
	The first word in the dictionary would be MNOO
	The second word is MONO.
	The third word is MOON.

Input:
T - No of test cases
A string, for rank testing (obviously!)

Output:
The rank.
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
using namespace std;
long factorial(int x)
{
	if (x==0 || x==1) return 1;
	else return x*factorial(x-1);
}
int main()
{
	int T;
	scanf("%d",&T);
	while (T--) {
		char str[100];
		scanf("%s",str);
		const int len = strlen(str);
		std::vector<char> v(len,'z');
		int *instance = new int[len];
		int countInstance[200] = {0};
	//std::cout<<"Point 1";
		for(int i=0;i<len;++i)
		{
			str[i] = toupper(str[i]);
			bool found = false;
			for(int j=0;j<i;++j)
				if (v[j] == str[i]) found = true;
			if (!found) v[i] = str[i];
			countInstance[(int) str[i]]++;
		}
		std::sort(v.begin(), v.end());

		int veclen = 0;
		for(veclen = 0; v[veclen]!='z' && veclen < len;++veclen);

	//		cout<<"Veclen:"<<veclen;
	#ifdef DEBUG
		std::cout<<"The sorted string:\n";
		for(std::vector<char>::const_iterator i = v.begin(); i!=v.end(); ++i)
			std::cout<<*i;
		std::cout<<"\n\n";
	#endif 

		for(int i=0;i<len;++i)
		{
			int temp = 0;
			for(int j=0;j<veclen;++j)
				if (str[i] == v[j]) temp = j + 1;
			instance[i] = temp;
		}

	#ifdef DEBUG
		std::cout<<"The instance array:\n";
		for(int i = 0;i < len; ++i)
			std::cout<<str[i]<<"\t"<<instance[i]<<"\n";
	#endif

	#ifdef DEBUG
		std::cout<<"The countInstance array:\n";
		for(int i=0;i<veclen;++i)
			std::cout<<v[i]<<"\t"<<countInstance[v[i]]<<"\n";
	#endif

		unsigned long long sum = 0;
	// Main Logic ->
		for(int lev = 0; lev < len; ++lev)
		{
			unsigned long long temp = 0;
			int after = 0;
			for(int i=lev;i<len;++i)
				if (instance[lev] > instance[i]) after++;
		#ifdef DEBUG
		std::cout<<"The after variable:\n";
			std::cout<<lev<<"\t"<<after<<"\n";
		#endif
			temp = after;
			temp*=factorial(len-lev-1);
			for(int i=0;i<veclen;++i)
			{
				temp/=factorial(countInstance[v[i]]);
			}
			countInstance[str[lev]]--;
		#ifdef DEBUG
			std::cout<<"TEMP at "<<lev<<" = "<<temp<<"\n";
		#endif
			sum+=temp;
		}
		printf("%lld\n",sum+1);
	}
	return 0;
}