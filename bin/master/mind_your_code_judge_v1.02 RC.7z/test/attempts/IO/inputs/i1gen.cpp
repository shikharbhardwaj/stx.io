/*
Random String Generator for Question 1.
*/

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#define DEF_TEST_CASES 10
#define MAX_STRING_LEN 10
int main(int argc, char const *argv[])
{
	srand(time(NULL));
	int i = 0;
	printf("%d\n",DEF_TEST_CASES);
	while(i++ < DEF_TEST_CASES)
	{
		int stringlen = rand() % MAX_STRING_LEN + 1;
		char *output = new char[stringlen];
		memset(output,'0',stringlen);
		for(int i=0;i<stringlen;++i)
		{
			output[i] = rand() % 25 + 65;
		}
		printf("%s\n",output);
	}
}