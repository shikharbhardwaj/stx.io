<!doctype html>
<html lang = "en">
<title>STX | Error</title>
<body>
<div id = "viewport">
<center>An error occured.</center>
<br>
<h2>Error</h2>
<br>
<?php
	if($_GET['id']==1){
		echo "Invalid team number.";
	}
	else if ($_GET['id']==2) {
		echo "Error establishing database connection";
	}
	else if($_GET['id']==3){
		echo "User does not exist";
	}
?>
</div>